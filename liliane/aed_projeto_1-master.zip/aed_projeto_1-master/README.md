# aed_projeto_1
Projeto 1 - Pós Graduação de Inteligência Artificial e Ciência de dados

